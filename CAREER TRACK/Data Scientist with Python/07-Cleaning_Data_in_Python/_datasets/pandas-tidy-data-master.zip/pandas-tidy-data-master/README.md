# Pandas and Tidy Data

Source code for my blog post: [English][1], [中文][2]

[1]: http://shzhangji.com/blog/2017/09/30/pandas-and-tidy-data/
[2]: http://shzhangji.com/cnblogs/2017/09/30/pandas-and-tidy-data/
